package com.example.calculo.viewmodel

import androidx.databinding.BaseObservable
import androidx.databinding.Bindable
import com.example.calculo.BR
import com.example.calculo.model.OhmModel

class OhmViewModel : BaseObservable() {
    private val model = OhmModel()

    @get:Bindable
    var resistance: String = ""
        set(value) {
            field = value
            notifyPropertyChanged(BR.resistance)
        }

    @get:Bindable
    var current: String = ""
        set(value) {
            field = value
            notifyPropertyChanged(BR.current)
        }

    @get:Bindable
    var voltage: String = ""
        private set(value) {
            field = value
            notifyPropertyChanged(BR.voltage)
        }

    fun calculate() {
        try {
            val r = resistance.toDoubleOrNull() ?: throw IllegalArgumentException("Resistência inválida")
            val i = current.toDoubleOrNull() ?: throw IllegalArgumentException("Corrente inválida")
            val v = model.calculateVoltage(r, i)
            voltage = v.toString()
        } catch (e: Exception) {
            voltage = "Erro: ${e.message}"
        }
    }
}