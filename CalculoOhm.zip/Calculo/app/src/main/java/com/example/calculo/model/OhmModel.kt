package com.example.calculo.model

class OhmModel {
    fun calculateVoltage(resistance: Double, current: Double): Double {
        if (resistance < 0 || current < 0) throw IllegalArgumentException("Valores não podem ser negativos")
        return resistance * current
    }
}