package com.example.calculadora.viewmodel

import android.util.Log
import androidx.databinding.BaseObservable
import androidx.databinding.Bindable
import com.example.calculadora.BR
import com.example.calculadora.model.CalculatorModel

class CalculatorViewModel : BaseObservable() {
    private val model = CalculatorModel()

    @get:Bindable
    var num1: String = ""
        set(value) {
            field = value
            Log.d("CalculatorViewModel", "num1 updated: $value")
            notifyPropertyChanged(BR.num1)
        }

    @get:Bindable
    var num2: String = ""
        set(value) {
            field = value
            Log.d("CalculatorViewModel", "num2 updated: $value")
            notifyPropertyChanged(BR.num2)
        }

    @get:Bindable
    var result: String = ""
        private set(value) {
            field = value
            Log.d("CalculatorViewModel", "result updated: $value")
            notifyPropertyChanged(BR.result)
        }

    fun setOperationAndCalculate(op: Char) {
        Log.d("CalculatorViewModel", "Button clicked, operation: $op, num1: $num1, num2: $num2")
        try {
            val n1 = num1.toDoubleOrNull() ?: throw IllegalArgumentException("Número 1 inválido")
            val n2 = num2.toDoubleOrNull() ?: throw IllegalArgumentException("Número 2 inválido")
            val res = when (op) {
                '+' -> model.add(n1, n2)
                '-' -> model.subtract(n1, n2)
                '*' -> model.multiply(n1, n2)
                '/' -> model.divide(n1, n2)
                else -> throw IllegalArgumentException("Operação inválida")
            }
            Log.d("CalculatorViewModel", "Calculation result: $res")
            result = res.toString()
        } catch (e: Exception) {
            Log.e("CalculatorViewModel", "Error: ${e.message}")
            result = "Erro: ${e.message}"
        }
    }
}